<?php
/**
 * Plugin Name: Themeum Startup Idea
 * Plugin URI: http://www.themeum.com/wordpress/startupidea
 * Description: Themeum Startup Idea is ultimate Crowdfunding plugins
 * Author: Themeum
 * Version: 2.9
 * Author URI: http://www.themeum.com
 *
 * Tested up to: 4.2
 * Text Domain: themeum-startup-idea
 *
 * @package Themeum Startup Idea
 * @category Core
 * @author Themeum
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if(!function_exists('themeum_pagination')):
    function themeum_pagination( $page_numb , $max_page )
    {	
    	$output = '';
        $big = 999999999; // need an unlikely integer
        $output .= '<div class="themeum-pagination">';
        $output .= paginate_links( array(
            'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format'    => '?paged=%#%',
            'current'   => $page_numb,
            'total'     => $max_page,
            'type'      => 'list',
            'prev_text' => __('<i class="fa fa-angle-left"></i>'),
            'next_text' => __('<i class="fa fa-angle-right"></i>'),
        ) );
        $output .= '</div>';
        return $output;
    }

endif;


if(!function_exists('themeum_get_ratting_data_html')):
    function themeum_get_ratting_data_html($rate){
        $x =1;
        $html = '<ul class="list-unstyled list-inline">';
        for ($j=1; $j<=5; $j++) {
            if($j<=floor($rate)){
                $html .= '<li><i class="fa fa-star"></i></li>';
            }else{
                if($x==1){
                    if($rate-floor($rate)>=0.5){
                        $html .= '<li><i class="fa fa-star-half-o"></i></li>';
                    }else{
                        $html .= '<li><i class="fa fa-star-o"></i></li>';    
                    }
                }else{
                    $html .= '<li><i class="fa fa-star-o"></i></li>';
                }
                $x++;
            }
        }

        $html .= '</ul>';
        return $html; 
    }
endif;



if( !function_exists('themeum_plugins_system_check') ):
    function themeum_plugins_system_check(){
        $data = get_option( 'themeum_options','' );

        if(!isset($data['system-plugins'])){
            return true;
        }else{
            if( $data['system-plugins']=='startupidea' ){
                return true;
            }else{
                return false;
            }
        }
    }
endif;





// Language File Loaded.
add_action( 'plugins_loaded', 'themeum_language_load' );
function themeum_language_load(){
  load_plugin_textdomain( 'themeum-startup-idea', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}



if( themeum_plugins_system_check() ){
    // Metabox Add
    include_once( 'post-type/meta_box.php' );
    include_once( 'post-type/meta-box/meta-box.php' );

    //Register Post Type 
    include_once( 'post-type/themeum-investment.php' );
    include_once( 'post-type/themeum-project.php' );

    // Shortcode ( Startupidea Default Shortcode )
    require_once( 'shortcodes/themeum-feature-ideas.php');
    require_once( 'shortcodes/themeum-project.php');
    require_once( 'shortcodes/themeum-project-listing.php');
    require_once( 'shortcodes/themeum-handpick-project.php');
    require_once( 'shortcodes/themeum-project-categories.php');
    require_once( 'shortcodes/themeum-category-projects.php');

    // Admin Menu
    include_once( 'admin/menus.php' );

    // Admin Dashboard
    include_once( 'admin/dashboard.php' );

    //Include plugins settings page
    include_once( 'themeum_startup_idea_settings.php' );

    //Add Themeum Payment module
    include_once( 'payment/paypal/paypalplatform.php');     // Paypal Class Add
    include_once( 'payment/payment-table.php' );            // Short the default table in Backend
    include_once( 'payment/payment-form-submit.php' );  
}else{

    // Shortcode ( WP Crowdfunding Shortcode )
    require_once( 'shortcodes/funding-feature-ideas.php');
    require_once( 'shortcodes/funding-project.php');
    require_once( 'shortcodes/funding-project-listing.php');
    require_once( 'shortcodes/funding-handpick-project.php');
    require_once( 'shortcodes/funding-project-categories.php');
    require_once( 'shortcodes/funding-category-projects.php');
}
