<?php
namespace PayPal\Exception;
/* Generic exception class
 */
class OAuthException extends \Exception {
	// pass
}
?>