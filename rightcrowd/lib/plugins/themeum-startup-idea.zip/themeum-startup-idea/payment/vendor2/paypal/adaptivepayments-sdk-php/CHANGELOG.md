### CHANGELOG

####Version 3.6.106 - August 22, 2013

	- Updated stubs.
    - Updated samples to showcase dynamic configuration.

You can see source code of this release in github under https://github.com/paypal/adaptivepayments-sdk-php/tree/v3.6.106
--------------------------------------------------------------------------------------------------

####Version 3.5.103 - June 11, 2013

	- Updated stubs for 103 release.
	- Removed deprecated methods like setAccessToken, getAccessToken from baseService in core.
    - Added correct thirdparty auth header in core.
	- Updated install script in samples to handle wildcard tag names. 

You can see source code of this release in github under https://github.com/paypal/adaptivepayments-sdk-php/tree/v3.5.103

--------------------------------------------------------------------------------------------------

#### Version 3.4.102 - May 20, 2013

    - Updating SDK to use NameSpaces, Supported from PHP 5.3 and above
    
You can see source code of this release in github under https://github.com/paypal/adaptivepayments-sdk-php/tree/v3.4.102