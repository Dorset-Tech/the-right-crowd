<html>

  <table align="center" style="text-align:left">
	        	<?php 
    		foreach($response as $key => $value) {
    			
    			echo "<tr><td> $key:</td><td>$value</td></tr>";
    			}	
       			?>
  </table>
</html>