<?php
add_shortcode( 'themeum_project_listing_funding', function($atts, $content = null) {

	extract(shortcode_atts(array(
		'number_of_project' 	 => '3',
		'order_by'			     => ''
		), $atts));


	$output = '';
    $max_page = 0;
    $currency_symbol = '';
    if( function_exists('get_woocommerce_currency_symbol') ){
        $currency_symbol = get_woocommerce_currency_symbol(get_option('woocommerce_currency',''));
    }


    $output .= '<div id="popular-ideas">';

    global $wp_query;
    $page_numb = max( 1, get_query_var('paged') );
    

    // The Query
    query_posts( array( 
        'post_type'         => 'product',
        'posts_per_page'    => esc_attr($number_of_project), 
        'order'             => esc_attr($order_by),
        'paged'             => $page_numb
    ) );
    // The Loop
    $inner = 1; $counter = 3;
    while ( have_posts() ) : the_post();
        $max_page = $wp_query->max_num_pages;
        //Fund Raised
        $total_raised = 0;
        if(function_exists('WPNEOCF')){
            $total_raised = WPNEOCF()->getFundRaisedPercent(get_the_ID());    
        }
        // Ratting HTML
        if(function_exists('WC')){
            $product = new WC_Product(get_the_ID());
            $rating = $product->get_average_rating();
        }
        // Location
        $var = get_post_meta(get_the_ID(), "wpneo_country", true);
        $location = get_post_meta(get_the_ID(), "_nf_location", true);
        if(function_exists('WC')){
            if($var!=''){ $location = $location.', '.WC()->countries->countries[$var]; }
        }
        //Funding Goal
        $funding_goal = get_post_meta(get_the_ID(),"_nf_funding_goal", true);

        // -----------------
        if( ($inner == 1)||($inner%3==1) ){ $output .= '<div class="row">'; }

        $output .= '<div class="col-sm-4">';
            $output .= '<div class="ideas-item">';
                $output .= '<div class="image">';
                    $output .= '<div class="fund-progress"><div class="bar" style="width:'.$total_raised.'%"></div></div>';
                    $output .= '<a href="'.get_the_permalink().'">';
                    $output .= '<figure>';
                    if ( has_post_thumbnail() && ! post_password_required() ){ 
                        $output .=  get_the_post_thumbnail( get_the_ID(), 'project-thumb', array('class' => 'img-responsive'));
                        }else {
                            $output .= '<div class="no-image"></div>';
                         }
                        $_product = wc_get_product( get_the_ID() );
                        $output .= '<figcaption>';
                            if( $_product->is_type( 'crowdfunding' ) ) {
                                $output .= '<p>'.$total_raised.'%</p>';
                                $output .= '<p class="pull-left">'.__("Rise Funded","themeum-startup-idea").'</p>';
                                $output .= themeum_get_ratting_data_html($rating);
                            }
                        $output .= '</figcaption>';
                    $output .= '</figure>';
                    $output .= '</a>';
                $output .= '</div>';
            
                $output .= '<div class="clearfix"></div>';
            
                $output .= '<div class="details">';
                    $output .= '<div class="country-name">'.esc_attr($location).'</div>';
                    $output .= '<h4><a href="'.get_the_permalink().'">'.get_the_title().'</a></h4>';
                    $output .= '<div class="entry-meta">';
                        $output .= '<span class="entry-food">'.get_the_term_list( get_the_ID(), 'product_tag', '<i class="fa fa-tags"></i> ', ', ' ).'</span>';
                        
                        if( $_product->is_type( 'crowdfunding' ) ) {
                            $output .= '<span class="entry-money"><i class="fa fa-money"></i> '.__('investment:','themeum-startup-idea').' <strong>'.$currency_symbol.esc_attr($funding_goal).'</strong></span>';
                        } else {
                            $output .= '<span class="entry-money"><i class="fa fa-money"></i> '.__('Price:','themeum-startup-idea').' <strong>'.$currency_symbol.$_product->get_price().'</strong></span>';
                        }
                        
                    $output .= '</div>';
                $output .= '</div> ';
            $output .= '</div>'; //ideas item
        $output .= '</div>';

        // -----------------
        if( $inner%3 == 0 ){ $output .= '</div>'; }
        
        $inner++;
    endwhile;
    if( $inner%3 != 0 ){ $output .= '</div>'; }
    // Reset Query
    wp_reset_query();

    $output .= themeum_pagination( $page_numb,$max_page );

    $output .= '</div>';

	return $output;

});


//Visual Composer
if (class_exists('WPBakeryVisualComposerAbstract')) {
vc_map(array(
	"name" => __("Project Listing", "themeum-startup-idea"),
	"base" => "themeum_project_listing_funding",
	'icon' => 'icon-thm-title',
	"class" => "",
	"description" => __("Widget Project", "themeum-startup-idea"),
	"category" => __('Themeum', "themeum-startup-idea"),
	"params" => array(

	array(
        "type" => "textfield",
        "heading" => __("Number Of Project","themeum-startup-idea"),
        "param_name" => "number_of_project",
        "description" => __("Enter the number of Project you want to display.", "themeum-startup-idea"),
        "value" => '', 
        ),

    array(
        "type" => "dropdown",
        "heading" => __("Order By:", "themeum-startup-idea"),
        "param_name" => "order_by",
        "value" => array('Date Create (Ascending)'=>'ASC','Date Create (Descending)'=>'DESC'),
        ),

		)
	));
}