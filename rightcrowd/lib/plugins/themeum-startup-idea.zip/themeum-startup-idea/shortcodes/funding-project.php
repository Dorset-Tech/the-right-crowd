<?php
add_shortcode( 'themeum_project_funding', function($atts, $content = null) {

	extract(shortcode_atts(array(
		'number_of_project' 	 => '3',
		'order_by'			     => 'ASC',
        'animation'              => 'fadeInLeft',
        'duration'               => '800',  
        'delay'                  => '200',        
		), $atts));

	$output = '';

    $dur = '';
    $item_del = '';
    $rating = '';

    if ($duration) $dur .= (int) esc_attr($duration); 
    if ($delay) $item_del .= (int) esc_attr($delay); 

    $currency_symbol = get_option('woocommerce_currency','');
    

    $output .= '<div id="popular-ideas" class="popular-ideas carousel">';

    // The Query
    query_posts( array( 
                        'post_type'         => 'product',
                        'posts_per_page'    =>  esc_attr($number_of_project),
                        'order'             => esc_attr($order_by)
                        ) );
    while ( have_posts() ) : the_post();
        $var = get_post_meta(get_the_ID(), "wpneo_country", true);
        $location = get_post_meta(get_the_ID(), "_nf_location", true);
        if(function_exists('WC')){
            if($var!=''){ $location = $location.', '.WC()->countries->countries[$var]; }
        }

        $funding_goal = get_post_meta(get_the_ID(), "_nf_funding_goal", true);

        $total_raised = 0;
        if(function_exists('WPNEOCF')){
            $total_raised = WPNEOCF()->getFundRaisedPercent(get_the_ID());    
        }
        
        if(function_exists('WC')){
            $product = new WC_Product(get_the_ID());

	        $rating_count = $product->get_rating_count();
	        $average      = $product->get_average_rating();

	        if ( function_exists('wpneo_wc_version_check')){
		        if (wpneo_wc_version_check()){
			        $rating =  wc_get_rating_html( $average, $rating_count );
		        }else{
			        $rating =  $product->get_rating_html();
		        }
	        }else{
		        global $woocommerce;
		        if ( version_compare( $woocommerce->version, '3.0', ">=" ) ) {
			        $rating = wc_get_rating_html( $average, $rating_count );
		        }else{
			        $rating = $product->get_rating_html();
		        }
	        }

        }

        $output .= '<div class="item wow '.esc_attr($animation).'" data-wow-duration="'.$dur.'ms" data-wow-delay="'.$item_del.'ms">';
            $output .= '<div class="image">';
                $output .= '<div class="fund-progress"><div class="bar" style="width:'.$total_raised.'%"></div></div>';
                 $output .= '<a href="'.get_the_permalink().'">';
                $output .= '<figure>';
                    if ( has_post_thumbnail() && ! post_password_required() ) { 
                    $output .=  get_the_post_thumbnail( get_the_ID(), 'project-thumb', array('class' => 'img-responsive'));
                    }else {
                        $output .= '<div class="no-image"></div>';
                    }
                    $output .= '<figcaption>';
                        $_product = wc_get_product( get_the_ID() );
                        if( $_product->is_type( 'crowdfunding' ) ) {
                            $output .= '<p>'.$total_raised.'%</p>';
                            $output .= '<p class="pull-left">'.__("Rise Funded","themeum-startup-idea").'</p>';
                            $output .= '<div class="woocommerce shortcode-rate-html">'.$rating.'</div>';
                        }
                    $output .= '</figcaption>';
                $output .= '</figure>';
                $output .= '</a>';
            $output .= '</div>'; //image
        
            $output .= '<div class="clearfix"></div>';
        
            $output .= '<div class="details">';
                $output .= '<div class="country-name">'.esc_attr($location).'</div>';
                $output .= '<h4><a href="'.get_the_permalink().'">'.get_the_title().'</a></h4>';
                $output .= '<div class="entry-meta">';
                    $output .= '<span class="entry-food">'.get_the_term_list( get_the_ID(), 'product_tag', '<i class="fa fa-tags"></i> ', ', ' ).'</span>';
                    if( $_product->is_type( 'crowdfunding' ) ) {
                        $output .= '<span class="entry-money"><i class="fa fa-money"></i> '.__('investment:','themeum-startup-idea').' <strong>'.$currency_symbol.esc_attr($funding_goal).'</strong></span>';
                    } else {
                        $output .= '<span class="entry-money"><i class="fa fa-money"></i> '.__('Price:','themeum-startup-idea').' <strong>'.$currency_symbol.$_product->get_price().'</strong></span>';
                    }
                $output .= '</div>';
            $output .= '</div> '; //details
        $output .= '</div>'; //item
        $dur = $dur+200;
        $item_del = $item_del+100;
    endwhile;
    // Reset Query
    wp_reset_query();
    $output .= '</div>'; //popular-ideas
	return $output;
});


//Visual Composer
if (class_exists('WPBakeryVisualComposerAbstract')) {
vc_map(array(
	"name" => __("Project", "themeum-startup-idea"),
	"base" => "themeum_project_funding",
	'icon' => 'icon-thm-title',
	"class" => "",
	"description" => __("Widget Project", "themeum-startup-idea"),
	"category" => __('Themeum', "themeum-startup-idea"),
	"params" => array(

	array(
        "type" => "textfield",
        "heading" => __("Number Of Project","themeum-startup-idea"),
        "param_name" => "number_of_project",
        "description" => __("Enter the number of Project you want to display.", "themeum-startup-idea"),
        "value" => '', 
        ),

    array(
        "type" => "dropdown",
        "heading" => __("Order By:", "themeum-startup-idea"),
        "param_name" => "order_by",
        "value" => array('Select'=>'','Date Create (Ascending)'=>'ASC','Date Create (Descending)'=>'DESC'),
        ),
    array(
        "type" => "dropdown",
        "heading" => __("Animation", "themeum-startup-idea"),
        "param_name" => "animation",
        "value" => array('Select'=>'','No Style'=>'','Fade in Left'=>'fadeInLeft','Fade in Down'=>'fadeInDown','Fade in Right'=>'fadeInRight','Fade in Up'=>'fadeInUp'),
        ),  
    array(
        "type" => "textfield",
        "heading" => __("Animation Duration", "themeum-startup-idea"),
        "param_name" => "duration",
        "value" => "",
        ),  

    array(
        "type" => "textfield",
        "heading" => __("Animation Delay", "themeum-startup-idea"),
        "param_name" => "delay",
        "value" => "",
        ),    

		)
	));
}