<?php

add_shortcode( 'themeum_handpick_project_funding', function($atts, $content = null) {

	extract(shortcode_atts(array(
		'number_of_project' 	=> '',
        'class'                 => ''
		), $atts));

	$output = '';
    $total_raised = 0;
    $rating = 0;
    $currency_symbol = '';

    if( function_exists('get_woocommerce_currency_symbol') ){
        $currency_symbol = get_woocommerce_currency_symbol(get_option('woocommerce_currency',''));
    }

    query_posts( array('p' => esc_attr($number_of_project), 'post_type' => 'product') );

    $output .= '<div id="handpick-project">';

    while ( have_posts() ) : the_post();
            //Fund Raised
            $total_raised = 0;
            if(function_exists('WPNEOCF')){
                $total_raised = WPNEOCF()->getFundRaisedPercent(get_the_ID());    
            }
            // Ratting HTML
            if(function_exists('WC')){
                $product = new WC_Product(get_the_ID());
                $rating = $product->get_average_rating();
            }
            // Location
            $var = get_post_meta(get_the_ID(), "wpneo_country", true);
            $location = get_post_meta(get_the_ID(), "_nf_location", true);
            if(function_exists('WC')){
                if($var!=''){ $location = $location.', '.WC()->countries->countries[$var]; }
            }

            $funding_goal = get_post_meta(get_the_ID(),"_nf_funding_goal", true);

            $output .= '<div class="handpick '.esc_attr($class).'">';

                $output .= '<p class="rise-pund">'.__("Fund Raised","themeum-startup-idea").'</p>';
                $wave = (140/100)*$total_raised;
                $output .= '<div class="loading wave" style="background-size: 75px '.$wave.'px;">';
                    $output .= '<h2>'.$total_raised.'<span>%</span></h2>';
                $output .= '</div>';
                $output .= '<p class="location">'.esc_attr($location).'</p>';
                $output .= '<h3>'.get_the_title().'</h3>';
                $output .= '<div class="info">';
                    $output .= '<div class="hp-project-meta">';
                        
                        $_product = wc_get_product( get_the_ID() );
                        if( $_product->is_type( 'crowdfunding' ) ) {
                            $output .= '<span class="entry-money"><i class="fa fa-money"></i> '.__('Total Investment:','themeum-startup-idea').' <strong>'.$currency_symbol.esc_attr($funding_goal).'</strong></span>';
                        } else {
                            $output .= '<span class="entry-money"><i class="fa fa-money"></i> '.__('Price:','themeum-startup-idea').' <strong>'.$currency_symbol.$_product->get_price().'</strong></span>';
                        }

                        $output .= '<span class="entry-rate">'.themeum_get_ratting_data_html($rating).'</span>';
                    $output .= '</div>';
                     $output .= '<p class="intotext">'.themeum_the_excerpt_max_charlength(110).'</p>';
                     $output .= '<a class="btn btn-default" href="'.get_the_permalink().'">'.__('See Idea','themeum-startup-idea').'</a>';
                $output .= '</div>';
        
            $output .= '</div>'; //ideas item

    endwhile;
    // Reset Query
    wp_reset_query();
    $output .= '</div>';  
	return $output;

});
add_action( 'init', function(){

$projects = get_posts( array(
    'posts_per_page'   => -1,
    'offset'           => 0,
    'orderby'          => 'post_date',
    'order'            => 'DESC',
    'post_type'        => 'product',
    'post_status'      => 'publish',
    'suppress_filters' => true 
) );

$list_project = array();

foreach ($projects as $post) {
    $list_project[$post->ID] = $post->post_title;
}
$list_project = array_flip($list_project );


//Visual Composer
if (class_exists('WPBakeryVisualComposerAbstract')) {
vc_map(array(
	"name" => __("Hand Pick Project", "themeum-startup-idea"),
	"base" => "themeum_handpick_project_funding",
	'icon' => 'icon-thm-title',
	"class" => "",
	"description" => __("Widget Project", "themeum-startup-idea"),
	"category" => __('Themeum', "themeum-startup-idea"),
	"params" => array(

	array(
        "type" => "dropdown",
        "heading" => __("Project Name","themeum-startup-idea"),
        "param_name" => "number_of_project",
        "description" => __("Eelect your Hand Pick Project", "themeum-startup-idea"),
        "value" => $list_project, 
        ),

    array(
        "type" => "textfield",
        "heading" => __("Custom Class ", "themeum-startup-idea"),
        "param_name" => "class",
        "value" => "",
        )    

		)
	));
}
});