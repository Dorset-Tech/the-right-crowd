<?php
add_shortcode( 'themeum_feature_ideas_funding', function($atts, $content = null) {

	extract(shortcode_atts(array(
        'category_number'   => '4',
		'order_by'			=> 'ASC'
		), $atts));

	$output = '';
	$category = array();
    $currency_symbol = '';
    if( function_exists('get_woocommerce_currency_symbol') ){
        $currency_symbol = get_woocommerce_currency_symbol(get_option('woocommerce_currency',''));
    }

	$reasult = get_terms('product_cat',array('order' => esc_attr($order_by )));

	$output .= '<div id="featured-ideas" class="tabpanel">';


        $output .= '<div class="navigation nav nav-tabs">';
            $output .= '<ul class="list-unstyled list-inline text-center">';
            $i = 1;
                foreach ( $reasult as $value ) {
                    if($i <= esc_attr($category_number)) {
                    		$category[] = $value->slug;
                        	if( $i == 1 ){
                        		$output .= '<li class="active"><a href="#'.$value->slug.'" data-toggle="tab">'.$value->name.'</a></li>';
                        	}else{
                        		$output .= '<li><a href="#'.$value->slug.'" data-toggle="tab">'.$value->name.'</a></li>';	
                        	}
                        }
                    	$i++;
                    }
            $output .= '</ul>';
        $output .= '</div>';

        $output .= '<div class="tab-content">';
        	$i=1;
        	foreach ($category as $value) {

            		if( $i == 1){
            			$output .= '<div class="details tab-pane active fade in" id="'.$value.'">';
            		}else{
            			$output .= '<div class="details tab-pane fade" id="'.$value.'">';
            		}
        			$i++;
		

            		// The Query
					query_posts( array( 
										'post_type' => 'product', 
										'product_cat' => $value , 
										'posts_per_page' => 1 , 
										'meta_query' => array(
											'relation' => 'AND',
														array(
															'key' => 'thm_featured',
															'value'=> 1,
															'compare' => '='
															)) 
										) );
					// The Loop
					while ( have_posts() ) : the_post();
						
						//Fund Raised
                        $total_raised = 0;
                        if(function_exists('WPNEOCF')){
                            $total_raised = WPNEOCF()->getFundRaisedPercent(get_the_ID());    
                        }
                        // Ratting HTML
                        if(function_exists('WC')){
                            $product = new WC_Product(get_the_ID());
                            $rating = $product->get_average_rating();
                        }
                        // Location
                        $var = get_post_meta(get_the_ID(), "wpneo_country", true);
                        $location = get_post_meta(get_the_ID(), "_nf_location", true);
                        if(function_exists('WC')){
                            if($var!=''){ $location = $location.', '.WC()->countries->countries[$var]; }
                        }
                        //Funding Goal
                        $funding_goal = get_post_meta(get_the_ID(),"_nf_funding_goal", true);

                         $output .= '<div class="item media">';
                             $output .= '<div class="pull-left">';
                             $output .= '<div class="image">';
                                 $output .= '<a href="'.get_the_permalink().'"><figure class="featured-image">';
                                 $output .= '<div class="fund-progress"><div class="bar" style="width:'.$total_raised.'%"></div></div>';
                                    if ( has_post_thumbnail() && ! post_password_required() ) { 
                                    $output .= get_the_post_thumbnail( get_the_ID(), 'featured-ideas', array('class' => 'img-responsive'));
                                    }else {
                                        $output .= '<div class="no-image"></div>';
                                    }
                                     $output .= '<figcaption>';
                                         $output .= '<p>'.$total_raised.'%</p>';
                                         $output .= '<p class="pull-left">'.__('Rise Funded','themeum-startup-idea').'</p>';
                                         $output .= themeum_get_ratting_data_html($rating);
                                     $output .= '</figcaption>';
                                 $output .= '</figure></a>';
                                $output .= '</div>';
                             $output .= '</div>';
                             $output .= '<div class="media-body" >';
                                 $output .= '<p class="team-name">'.esc_attr($location).'</p>';
                                 $output .= '<h4><a href="'.get_the_permalink().'">'.get_the_title().'</a></h4>';
                                 $output .= '<div class="entry-meta">';
                                     $output .= '<span class="entry-tag"> '.get_the_term_list( get_the_ID(), 'product_tag', '<i class="fa fa-tags"></i> ', ', ' ).'</span>';
                                     $output .= '<span class="entry-comments"><i class="fa fa-money"></i> '.__('Total Investment','themeum-startup-idea').': <strong>'.$currency_symbol.esc_attr($funding_goal).'</strong></span>';
                                 $output .= '</div>';
                                 $output .= '<p>';
                                     $output .= themeum_the_excerpt_max_charlength(200);
                                $output .= '</p>';
                                $output .= '<a href="'.get_the_permalink().'" class="btn btn-default">'.__('Learn More','themeum-startup-idea').'</a>';
                                 
                             $output .= '</div>';
                         $output .= '</div>';
                     $output .= '</div>';

                endwhile;
				// Reset Query
				wp_reset_query();

        	}

        $output .= '</div>';
    $output .= '</div>';

	return $output;

});


//Visual Composer
if (class_exists('WPBakeryVisualComposerAbstract')) {
vc_map(array(
	"name" => __("Feature Ideas", "themeum-startup-idea"),
	"base" => "themeum_feature_ideas_funding",
	'icon' => 'icon-thm-title',
	"class" => "",
	"description" => __("Widget Title Heading", "themeum-startup-idea"),
	"category" => __('Themeum', "themeum-startup-idea"),
	"params" => array(

	array(
        "type" => "textfield",
        "heading" => __("Number Of Category","themeum-startup-idea"),
        "param_name" => "category_number",
        "description" => __("Enter the number of Category you want to display.", "themeum-startup-idea"),
        "value" => '', 
        ),

    array(
        "type" => "dropdown",
        "heading" => __("Order By:", "themeum-startup-idea"),
        "param_name" => "order_by",
        "value" => array('Select'=>'','Date Create (Ascending)'=>'ASC','Date Create (Descending)'=>'DESC'),
        ),         	

		)
	));
}